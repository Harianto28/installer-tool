if ('serviceWorker' in navigator && 'PushManager' in window) {
  navigator.serviceWorker.register('/sw.js').then(swReg => {
    console.log('Service Worker Registered', swReg);

    document.getElementById('subscribe').onclick = async () => {
      const permission = await Notification.requestPermission();
      if (permission !== 'granted') return alert('Notification permission denied');

      const subscription = await swReg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: '<REPLACE_WITH_PUBLIC_KEY>'
      });

      await fetch('/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(subscription)
      });

      alert('Subscribed successfully!');
    };
  });
}