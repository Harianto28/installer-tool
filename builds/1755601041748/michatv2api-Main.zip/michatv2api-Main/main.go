package main

import (
	"database/sql"
	"net/http"

	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
	_ "github.com/go-sql-driver/mysql"
)

type User struct {
	ID         int    `json:"id"`
	Email      string `json:"email"`
	Password   string `json:"password"`
	DeviceID   string `json:"device_id"`
	Coordinate string `json:"coordinate"`
	Message    string `json:"message"`
}

type Device struct {
	ID       int    `json:"id"`
	DeviceID string `json:"device_id"`
}

func main() {
	dsn := "jeremy:Qazwsx@123@tcp(10.0.0.38:3306)/michatv2"

	db, err := sql.Open("mysql", dsn)
	if err != nil {
		panic(err)
	}
	defer db.Close()

	if err := db.Ping(); err != nil {
		panic("Database connection failed: " + err.Error())
	}

	router := gin.Default()

	// Configure CORS middleware
	config := cors.DefaultConfig()
	config.AllowAllOrigins = true
	config.AllowMethods = []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"}
	config.AllowHeaders = []string{"Origin", "Content-Type", "Content-Length", "Accept-Encoding", "X-CSRF-Token", "Authorization"}
	config.AllowCredentials = true

	router.Use(cors.New(config))

	// ✅ GET all devices
	router.GET("/devices", func(c *gin.Context) {
		rows, err := db.Query("SELECT id, device_id FROM devices")
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
			return
		}
		defer rows.Close()

		var devices []Device
		for rows.Next() {
			var d Device
			if err := rows.Scan(&d.ID, &d.DeviceID); err != nil {
				c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
				return
			}
			devices = append(devices, d)
		}

		c.JSON(http.StatusOK, devices)
	})
	// ✅ GET all accounts
	router.GET("/accountCredentials", func(c *gin.Context) {
		rows, err := db.Query(`
		SELECT ac.id, ac.email, ac.password, d.device_id, ac.coordinate, ac.message
		FROM accountCredentials ac
		LEFT JOIN devices d ON ac.device_id = d.id
	`)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
			return
		}
		defer rows.Close()

		var users []User
		for rows.Next() {
			var user User
			if err := rows.Scan(
				&user.ID,
				&user.Email,
				&user.Password,
				&user.DeviceID,
				&user.Coordinate,
				&user.Message,
			); err != nil {
				c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
				return
			}
			users = append(users, user)
		}

		c.JSON(http.StatusOK, users)
	})

	// ✅ GET account credentials by device_id
	router.GET("/accountCredentials/:device_id", func(c *gin.Context) {
		deviceID := c.Param("device_id")

		query := `
			SELECT ac.id, ac.email, ac.password, ac.coordinate, ac.message
			FROM accountCredentials ac
			JOIN devices d ON ac.device_id = d.id
			WHERE d.device_id = ?
		`

		rows, err := db.Query(query, deviceID)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{
				"message": "Failed to query account credentials",
				"error":   err.Error(),
			})
			return
		}
		defer rows.Close()

		var users []User
		for rows.Next() {
			var user User
			if err := rows.Scan(
				&user.ID,
				&user.Email,
				&user.Password,
				&user.Coordinate,
				&user.Message,
			); err != nil {
				c.JSON(http.StatusInternalServerError, gin.H{
					"message": "Failed to parse account credentials",
					"error":   err.Error(),
				})
				return
			}

			users = append(users, user)
		}

		if err := rows.Err(); err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{
				"message": "Error reading query results",
				"error":   err.Error(),
			})
			return
		}

		c.JSON(http.StatusOK, gin.H{
			"message": "Account credentials retrieved successfully",
			"data":    users,
		})
	})

	// ✅ POST - Create new device
	router.POST("/devices", func(c *gin.Context) {
		var device Device
		if err := c.ShouldBindJSON(&device); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request body: " + err.Error()})
			return
		}

		if device.DeviceID == "" {
			c.JSON(http.StatusBadRequest, gin.H{"error": "device_id is required"})
			return
		}

		result, err := db.Exec("INSERT INTO devices (device_id) VALUES (?)", device.DeviceID)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to create device: " + err.Error()})
			return
		}

		id, _ := result.LastInsertId()
		device.ID = int(id)

		c.JSON(http.StatusCreated, gin.H{
			"message": "Device created successfully",
			"data":    device,
		})
	})

	// ✅ PUT - Update device
	router.PUT("/devices/:id", func(c *gin.Context) {
		id := c.Param("id")
		var device Device
		if err := c.ShouldBindJSON(&device); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request body: " + err.Error()})
			return
		}

		if device.DeviceID == "" {
			c.JSON(http.StatusBadRequest, gin.H{"error": "device_id is required"})
			return
		}

		result, err := db.Exec("UPDATE devices SET device_id = ? WHERE id = ?", device.DeviceID, id)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to update device: " + err.Error()})
			return
		}

		rowsAffected, _ := result.RowsAffected()
		if rowsAffected == 0 {
			c.JSON(http.StatusNotFound, gin.H{"error": "Device not found"})
			return
		}

		c.JSON(http.StatusOK, gin.H{
			"message": "Device updated successfully",
			"data":    gin.H{"id": id, "device_id": device.DeviceID},
		})
	})

	// ✅ DELETE - Delete device
	router.DELETE("/devices/:id", func(c *gin.Context) {
		id := c.Param("id")

		result, err := db.Exec("DELETE FROM devices WHERE id = ?", id)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to delete device: " + err.Error()})
			return
		}

		rowsAffected, _ := result.RowsAffected()
		if rowsAffected == 0 {
			c.JSON(http.StatusNotFound, gin.H{"error": "Device not found"})
			return
		}

		c.JSON(http.StatusOK, gin.H{
			"message": "Device deleted successfully",
		})
	})

	// ✅ POST - Create new account credentials
	router.POST("/accountCredentials", func(c *gin.Context) {
		var user User
		if err := c.ShouldBindJSON(&user); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request body: " + err.Error()})
			return
		}

		if user.Email == "" || user.Password == "" {
			c.JSON(http.StatusBadRequest, gin.H{"error": "email and password are required"})
			return
		}

		// First, get or create device_id
		var deviceID int64
		if user.DeviceID != "" {
			// Check if device exists, if not create it
			err := db.QueryRow("SELECT id FROM devices WHERE device_id = ?", user.DeviceID).Scan(&deviceID)
			if err != nil {
				// Device doesn't exist, create it
				result, err := db.Exec("INSERT INTO devices (device_id) VALUES (?)", user.DeviceID)
				if err != nil {
					c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to create device: " + err.Error()})
					return
				}
				deviceID, _ = result.LastInsertId()
			}
		}

		query := `
			INSERT INTO accountCredentials (email, password, device_id, coordinate, message) 
			VALUES (?, ?, ?, ?, ?)
		`
		result, err := db.Exec(query, user.Email, user.Password, deviceID, user.Coordinate, user.Message)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to create account credentials: " + err.Error()})
			return
		}

		id, _ := result.LastInsertId()
		user.ID = int(id)

		c.JSON(http.StatusCreated, gin.H{
			"message": "Account credentials created successfully",
			"data":    user,
		})
	})

	// ✅ PUT - Update account credentials
	router.PUT("/accountCredentials/:id", func(c *gin.Context) {
		id := c.Param("id")
		var user User
		if err := c.ShouldBindJSON(&user); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request body: " + err.Error()})
			return
		}

		// Build dynamic update query
		var updates []string
		var values []interface{}
		var args []interface{}

		if user.Email != "" {
			updates = append(updates, "email = ?")
			values = append(values, user.Email)
		}
		if user.Password != "" {
			updates = append(updates, "password = ?")
			values = append(values, user.Password)
		}
		if user.Coordinate != "" {
			updates = append(updates, "coordinate = ?")
			values = append(values, user.Coordinate)
		}
		if user.Message != "" {
			updates = append(updates, "message = ?")
			values = append(values, user.Message)
		}

		if len(updates) == 0 {
			c.JSON(http.StatusBadRequest, gin.H{"error": "At least one field must be provided for update"})
			return
		}

		// Handle device_id update if provided
		if user.DeviceID != "" {
			// Check if device exists, if not create it
			var deviceID int64
			err := db.QueryRow("SELECT id FROM devices WHERE device_id = ?", user.DeviceID).Scan(&deviceID)
			if err != nil {
				// Device doesn't exist, create it
				result, err := db.Exec("INSERT INTO devices (device_id) VALUES (?)", user.DeviceID)
				if err != nil {
					c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to create device: " + err.Error()})
					return
				}
				deviceID, _ = result.LastInsertId()
			}
			updates = append(updates, "device_id = ?")
			values = append(values, deviceID)
		}

		args = append(values, id)
		query := "UPDATE accountCredentials SET " + updates[0]
		for i := 1; i < len(updates); i++ {
			query += ", " + updates[i]
		}
		query += " WHERE id = ?"

		result, err := db.Exec(query, args...)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to update account credentials: " + err.Error()})
			return
		}

		rowsAffected, _ := result.RowsAffected()
		if rowsAffected == 0 {
			c.JSON(http.StatusNotFound, gin.H{"error": "Account credentials not found"})
			return
		}

		c.JSON(http.StatusOK, gin.H{
			"message": "Account credentials updated successfully",
		})
	})

	// ✅ DELETE - Delete account credentials
	router.DELETE("/accountCredentials/:id", func(c *gin.Context) {
		id := c.Param("id")

		result, err := db.Exec("DELETE FROM accountCredentials WHERE id = ?", id)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to delete account credentials: " + err.Error()})
			return
		}

		rowsAffected, _ := result.RowsAffected()
		if rowsAffected == 0 {
			c.JSON(http.StatusNotFound, gin.H{"error": "Account credentials not found"})
			return
		}

		c.JSON(http.StatusOK, gin.H{
			"message": "Account credentials deleted successfully",
		})
	})

	router.Run(":3031")
}
