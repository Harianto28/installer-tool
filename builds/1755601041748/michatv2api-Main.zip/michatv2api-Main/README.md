# MichatV2 API Dashboard

A modern, responsive dashboard built with Go (Gin) and Tailwind CSS, featuring a clean interface similar to modern web applications.

## Features

### 🎨 **Modern UI Design**
- Clean, minimalist design with Tailwind CSS
- Responsive layout that works on all devices
- Professional color scheme with blue accent colors
- Smooth animations and hover effects

### 🧭 **Navigation Sidebar**
- Company branding in the top bar
- Main navigation menu with icons
- Saved reports section with quick access
- Settings and sign out options at the bottom

### 📊 **Dashboard Content**
- **Replaced the graph** with a comprehensive data table
- Search functionality to find any element in the table
- Action buttons (Share, Export, Date range selector)
- Floating action button for quick actions

### 🔍 **Search Functionality**
- Real-time search across all table columns
- Search by ID, Email, Device ID, or Status
- Clear search option to reset results
- Enter key support for quick searching

### 📋 **Data Table**
- Displays user data with columns: ID, Email, Device ID, Status, Actions
- Status badges with color coding (Active, Inactive, Pending)
- Action buttons for edit and delete operations
- Hover effects and smooth animations

## Prerequisites

### 1. Install Go
Make sure you have Go installed on your system. If not, follow these steps:

#### For Ubuntu/Debian:
```bash
sudo apt update
sudo apt install golang-go
```

#### For macOS (using Homebrew):
```bash
brew install go
```

#### For Windows:
Download the installer from [golang.org](https://golang.org/dl/)

#### Verify Installation:
```bash
go version
```

### 2. Install MySQL
The application requires MySQL database. Install it using:

#### For Ubuntu/Debian:
```bash
sudo apt update
sudo apt install mysql-server
sudo mysql_secure_installation
```

#### For macOS (using Homebrew):
```bash
brew install mysql
brew services start mysql
```

#### For Windows:
Download MySQL Installer from [mysql.com](https://dev.mysql.com/downloads/installer/)

### 3. Install Go Dependencies
Navigate to the project directory and install the required Go packages:

```bash
cd /path/to/michatv2api
go mod tidy
```

## Database Setup

### 1. Create Database
First, create a MySQL database for the application:

```sql
CREATE DATABASE michatv2;
USE michatv2;
```

### 2. Create Tables
Run the following SQL queries to create the required tables:

```sql
CREATE TABLE devices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    device_id VARCHAR(255) NOT NULL UNIQUE
);

CREATE TABLE accountCredentials (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    device_id INT, 
    coordinate VARCHAR(50),
    message VARCHAR(255),
    FOREIGN KEY (device_id) REFERENCES devices(id)
);
```

### 3. Insert Sample Data
Add some initial data to test the application:

```sql
INSERT INTO devices (device_id) VALUES
('3e87b87565cb6e15'),
('db1c17aaf8a8c731');

INSERT INTO accountCredentials (email, password, device_id, coordinate, message)
VALUES
(
  'enengemarahmawati@gmail.com',
  'keranair',
  (SELECT id FROM devices WHERE device_id = '3e87b87565cb6e15'),
  '-7.2504,112.7688',
  'Hello! Nice to meet you!'
),
(
  'lakosamo15@gmail.com',
  'keranair',
  (SELECT id FROM devices WHERE device_id = 'db1c17aaf8a8c731'),
  '-6.2088,106.8456',
  'Hello! Nice to meet you!'
),
(
  'munawarohmira624@gmail.com',
  'keranair',
  (SELECT id FROM devices WHERE device_id = 'db1c17aaf8a8c731'),
  '-8.6500,112.2167',
  'Hello! Nice to meet you!'
);
```

## Project Structure

```
michatv2api/
├── main.go                 # Go server with API endpoints
├── go.mod                  # Go module dependencies
├── go.sum                  # Go module checksums
├── templates/
│   └── dashboard.html     # Main dashboard template
├── static/
│   └── css/
│       └── custom.css     # Custom CSS animations
└── README.md              # This file
```

## Getting Started

### 1. Clone and Setup
```bash
git clone <your-repository-url>
cd michatv2api
```

### 2. Configure Database Connection
Update the database connection settings in `main.go` to match your MySQL configuration. You'll need to change the DSN (Data Source Name) string:

```go
// Change this line in main.go (around line 27)
dsn := "jeremy:Qazwsx@123@tcp(10.0.0.38:3306)/michatv2"

// Replace with your own database credentials:
// Format: "username:password@tcp(host:port)/database_name"
// Example: "youruser:yourpassword@tcp(localhost:3306)/michatv2"
```

### 3. Install Dependencies
```bash
go mod tidy
```

### 4. Run the Application
```bash
go run main.go
```

### 5. Access the Dashboard
Open your browser and navigate to:
```
http://localhost:3031
```

## API Endpoints

The dashboard loads data from these API endpoints:
- `GET /accountCredentials` - Get all user accounts
- `GET /devices` - Get all devices
- `GET /peopleNearbyCredentials` - Get nearby people data

## Customization

### Loading Real Data
To load data from your Go API instead of sample data:

1. Uncomment this line in `templates/dashboard.html`:
```javascript
// loadDataFromAPI();
```

2. The dashboard will automatically fetch and display data from your `/accountCredentials` endpoint.

### Styling
- **Tailwind CSS**: All styling is done with Tailwind utility classes
- **Custom CSS**: Additional animations and effects in `static/css/custom.css`
- **Colors**: Easily customizable through the Tailwind config in the HTML file

### Table Columns
Modify the table structure by editing the `<thead>` section and the `renderTable()` function in the JavaScript code.

## Features in Detail

### Search Implementation
- **Real-time filtering**: Search updates as you type
- **Multi-column search**: Searches across ID, Email, Device ID, and Status
- **Case-insensitive**: Search works regardless of case
- **Partial matching**: Finds partial matches in any field

### Responsive Design
- **Mobile-friendly**: Sidebar collapses on small screens
- **Flexible layout**: Content adapts to different screen sizes
- **Touch-friendly**: Optimized for touch devices

### Performance
- **Efficient rendering**: Only re-renders changed table rows
- **Smooth animations**: CSS transitions for better user experience
- **Optimized search**: Fast filtering with JavaScript

## Troubleshooting

### Common Issues

1. **Port already in use**: Change the port in `main.go` from 3031 to another available port
2. **Database connection failed**: Verify MySQL is running and credentials are correct
3. **Go modules not found**: Run `go mod tidy` to download dependencies
4. **Permission denied**: Ensure you have proper permissions for the project directory

### Database Connection Issues
- Verify MySQL service is running: `sudo systemctl status mysql`
- Check if MySQL is listening on the correct port: `netstat -tlnp | grep 3306`
- Ensure the database user has proper permissions

## Browser Support
- Chrome (recommended)
- Firefox
- Safari
- Edge

## Dependencies
- **Go 1.16+** with Gin framework
- **MySQL 8.0+** or **MySQL 5.7+**
- **Tailwind CSS** (loaded via CDN)
- **Font Awesome** (loaded via CDN)

## Future Enhancements
- [ ] Pagination for large datasets
- [ ] Sorting functionality
- [ ] Export to CSV/Excel
- [ ] User authentication
- [ ] Dark mode toggle
- [ ] More interactive charts and graphs
- [ ] Real-time data updates

## Contributing
Feel free to modify and enhance the dashboard according to your needs. The code is well-structured and commented for easy customization.

## License
This project is open source and available under the [MIT License](LICENSE).





